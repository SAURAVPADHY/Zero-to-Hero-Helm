# SMB single-region Azure hub-and-spoke with Azure Firewall (Terraform)

This is a compact, standalone learning implementation inspired by the Azure Landing Zones Accelerator scenario. It is **not** a full deployment of the ALZ accelerator: it includes a hub VNet, Azure Firewall + policy, two spoke VNets, hub/spoke peerings, and default-route UDRs. It omits management groups/policies, VPN gateway, Log Analytics/AMA, private DNS, Bastion, and DDoS protection to keep the sample focused.

## Prerequisites
- Terraform >= 1.6
- Azure CLI (`az login`)
- Azure subscription permissions to create VNets, public IPs, firewall, policies, and route tables

## Deploy

```bash
az login
az account set --subscription <SUBSCRIPTION_ID>
cp terraform.tfvars.example terraform.tfvars
# Edit subscription_id in terraform.tfvars
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
```

Windows PowerShell can use `Copy-Item terraform.tfvars.example terraform.tfvars` instead of `cp`.

## Important notes
- Azure Firewall has material hourly and data-processing costs. Check pricing for your region/SKU before applying.
- `Basic` is selected for SMB cost control. Consider Standard/Premium for advanced requirements; verify SKU features and regional availability before changing.
- The sample allows only HTTPS to `*.ubuntu.com` and `*.microsoft.com`. This is a demo allow-list, not a complete production egress policy. Add required FQDNs, service tags, and network rules deliberately.
- A UDR alone does not guarantee all traffic paths are inspected. Test effective routes and firewall logs. Spoke-to-spoke routing requires correct routes and firewall policy/rules; this minimal sample should be treated as a foundation, not a fully validated production segmentation design.
- There is no VPN/ExpressRoute, Bastion, centralized Private DNS, monitoring workspace, DDoS plan, or remote state configured.
- For production, use remote state in a secured Azure Storage account, workload identity/OIDC for CI, pinned provider versions, policy checks, plan review, diagnostic settings, and change approvals.

## Verify

```bash
terraform output
az network firewall show --resource-group "$(terraform output -raw resource_group_name)" --name "afw-smb-alz" --query '{privateIP:ipConfigurations[0].privateIPAddress,provisioningState:provisioningState}'
```

## Destroy lab resources

```bash
terraform plan -destroy -out=destroy.tfplan
terraform apply destroy.tfplan
```
