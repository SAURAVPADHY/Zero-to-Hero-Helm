output "resource_group_name" {
  value = azurerm_resource_group.network.name
}

output "firewall_private_ip" {
  value = azurerm_firewall.main.ip_configuration[0].private_ip_address
}

output "firewall_public_ip" {
  value = azurerm_public_ip.firewall.ip_address
}

output "hub_vnet_id" {
  value = azurerm_virtual_network.hub.id
}

output "spoke_vnet_ids" {
  value = { for name, vnet in azurerm_virtual_network.spoke : name => vnet.id }
}
