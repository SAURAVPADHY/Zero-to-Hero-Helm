variable "subscription_id" {
  description = "Target Azure subscription ID. Set ARM_SUBSCRIPTION_ID or provide a value in terraform.tfvars."
  type        = string
}

variable "location" {
  description = "Single Azure region for this SMB lab."
  type        = string
  default     = "centralindia"
}

variable "prefix" {
  description = "Short prefix used for resource names. Use lowercase letters/numbers/hyphens."
  type        = string
  default     = "smb-alz"
}

variable "tags" {
  type = map(string)
  default = {
    environment = "lab"
    managed_by  = "terraform"
  }
}

variable "firewall_sku_tier" {
  description = "Azure Firewall tier. Basic is lower cost; Standard/Premium provide more features."
  type        = string
  default     = "Basic"
  validation {
    condition     = contains(["Basic", "Standard", "Premium"], var.firewall_sku_tier)
    error_message = "firewall_sku_tier must be Basic, Standard, or Premium."
  }
}
