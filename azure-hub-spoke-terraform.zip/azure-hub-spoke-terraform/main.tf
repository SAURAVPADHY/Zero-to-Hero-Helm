resource "azurerm_resource_group" "network" {
  name     = "rg-${var.prefix}-network"
  location = var.location
  tags     = var.tags
}

# Hub VNet: firewall and shared network services live here.
resource "azurerm_virtual_network" "hub" {
  name                = "vnet-${var.prefix}-hub"
  location            = azurerm_resource_group.network.location
  resource_group_name = azurerm_resource_group.network.name
  address_space       = ["10.0.0.0/16"]
  tags                = var.tags
}

resource "azurerm_subnet" "firewall" {
  name                 = "AzureFirewallSubnet" # Azure-required exact name
  resource_group_name  = azurerm_resource_group.network.name
  virtual_network_name = azurerm_virtual_network.hub.name
  address_prefixes     = ["10.0.0.0/26"]
}

resource "azurerm_public_ip" "firewall" {
  name                = "pip-${var.prefix}-firewall"
  location            = azurerm_resource_group.network.location
  resource_group_name = azurerm_resource_group.network.name
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_firewall_policy" "main" {
  name                = "afwp-${var.prefix}"
  location            = azurerm_resource_group.network.location
  resource_group_name = azurerm_resource_group.network.name
  sku                 = var.firewall_sku_tier
  threat_intelligence_mode = "Alert"
  tags                = var.tags
}

# Example egress allow-list. Add only the FQDNs/ports your workloads require.
resource "azurerm_firewall_policy_rule_collection_group" "egress" {
  name               = "rcg-${var.prefix}-egress"
  firewall_policy_id = azurerm_firewall_policy.main.id
  priority           = 100

  application_rule_collection {
    name     = "allow-approved-web"
    priority = 100
    action   = "Allow"

    rule {
      name = "allow-ubuntu-and-microsoft"
      protocols {
        type = "Https"
        port = 443
      }
      source_addresses  = ["10.1.0.0/16", "10.2.0.0/16"]
      destination_fqdns = ["*.ubuntu.com", "*.microsoft.com"]
    }
  }
}

resource "azurerm_firewall" "main" {
  name                = "afw-${var.prefix}"
  location            = azurerm_resource_group.network.location
  resource_group_name = azurerm_resource_group.network.name
  sku_name            = "AZFW_VNet"
  sku_tier            = var.firewall_sku_tier
  firewall_policy_id  = azurerm_firewall_policy.main.id
  tags                = var.tags

  ip_configuration {
    name                 = "firewall-ipconfig"
    subnet_id            = azurerm_subnet.firewall.id
    public_ip_address_id = azurerm_public_ip.firewall.id
  }
}

# Two workload spokes. Keep CIDRs non-overlapping with each other and your on-prem networks.
resource "azurerm_virtual_network" "spoke" {
  for_each            = { app = "10.1.0.0/16", data = "10.2.0.0/16" }
  name                = "vnet-${var.prefix}-${each.key}"
  location            = azurerm_resource_group.network.location
  resource_group_name = azurerm_resource_group.network.name
  address_space       = [each.value]
  tags                = var.tags
}

resource "azurerm_subnet" "workload" {
  for_each             = azurerm_virtual_network.spoke
  name                 = "snet-workload"
  resource_group_name  = azurerm_resource_group.network.name
  virtual_network_name = each.value.name
  address_prefixes     = [each.key == "app" ? "10.1.1.0/24" : "10.2.1.0/24"]
}

# Bidirectional peering. Do not enable direct spoke-to-spoke peering; use the hub/firewall path.
resource "azurerm_virtual_network_peering" "hub_to_spoke" {
  for_each                  = azurerm_virtual_network.spoke
  name                      = "peer-hub-to-${each.key}"
  resource_group_name       = azurerm_resource_group.network.name
  virtual_network_name      = azurerm_virtual_network.hub.name
  remote_virtual_network_id = each.value.id
  allow_forwarded_traffic   = true
  allow_virtual_network_access = true
}

resource "azurerm_virtual_network_peering" "spoke_to_hub" {
  for_each                  = azurerm_virtual_network.spoke
  name                      = "peer-${each.key}-to-hub"
  resource_group_name       = azurerm_resource_group.network.name
  virtual_network_name      = each.value.name
  remote_virtual_network_id = azurerm_virtual_network.hub.id
  allow_forwarded_traffic   = true
  allow_virtual_network_access = true
}

# Force workload subnet default-route traffic to Azure Firewall.
resource "azurerm_route_table" "spoke" {
  for_each                      = azurerm_virtual_network.spoke
  name                          = "rt-${var.prefix}-${each.key}"
  location                      = azurerm_resource_group.network.location
  resource_group_name           = azurerm_resource_group.network.name
  disable_bgp_route_propagation = false
  tags                          = var.tags

  route {
    name                   = "default-via-firewall"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = azurerm_firewall.main.ip_configuration[0].private_ip_address
  }
}

resource "azurerm_subnet_route_table_association" "spoke" {
  for_each       = azurerm_subnet.workload
  subnet_id      = each.value.id
  route_table_id = azurerm_route_table.spoke[each.key].id
}
